int executecmds(Cmd *, char *, char *, int *);
