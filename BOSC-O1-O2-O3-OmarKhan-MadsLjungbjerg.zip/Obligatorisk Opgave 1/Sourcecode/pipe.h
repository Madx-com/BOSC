/* 
   Opgave 3

   pipe.h

 */

#ifndef _PIPE_H
#define _PIPE_H

int pipecmd(char *filename, char *argv[], char *filename2, char *argv2[]);

#endif
